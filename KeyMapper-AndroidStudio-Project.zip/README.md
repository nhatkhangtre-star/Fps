# HƯỚNG DẪN XUẤT FILE APK TỪ DỰ ÁN NÀY

Dự án này đã được cấu hình trọn vẹn 100% cho **com.example.keymapper**.

## CÁCH 1: Dùng Android Studio (Khuyên dùng - Nhanh nhất)
1. Tải và giải nén thư mục này.
2. Mở **Android Studio** -> Chọn **Open** -> Chọn thư mục vừa giải nén.
3. Chờ Gradle tải thư viện xong (khoảng 30 giây).
4. Trên thanh menu, chọn:
   **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**
5. Khi build xong, Android Studio sẽ hiện thông báo góc dưới: **"locate"** -> Bấm vào để lấy ngay file **app-debug.apk**!
6. Chép file APK vào điện thoại Android và cài đặt.

## CÁCH 2: Build APK Online Miễn Phí (Không Cần Cài Android Studio)
Dự án đã có sẵn file tự động build: `.github/workflows/build-apk.yml`
1. Đăng nhập vào [GitHub.com](https://github.com) -> Tạo một repository mới.
2. Tải toàn bộ các file trong thư mục này lên GitHub.
3. Vào tab **Actions** -> Bạn sẽ thấy GitHub tự động chạy tiến trình compile APK.
4. Sau 2 phút, bấm vào Artifacts và tải file **KeyMapper-Debug-APK.zip** (bên trong có sẵn file APK để cài lên điện thoại).

## CÁCH 3: Test Trực Tiếp Bằng Cáp USB Không Cần Build APK (Qua ADB)
Nếu bạn có máy tính kết nối điện thoại qua cáp USB và bật "USB Debugging":
Chỉ cần chạy lệnh:
```bash
adb shell input tap 500 1000
adb shell input tap 300 1200
adb shell input tap 700 1200
```
