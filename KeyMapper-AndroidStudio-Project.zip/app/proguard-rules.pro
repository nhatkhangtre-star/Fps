# Proguard rules
-keep class com.example.keymapper.** { *; }
