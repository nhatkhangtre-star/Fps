package com.example.keymapper

import android.view.KeyEvent
import android.util.Log

/**
 * KeyDispatcher - Quản lý lắng nghe phím vật lý & ánh xạ tọa độ
 * Hỗ trợ cả 2 chế độ: Activity.dispatchKeyEvent và AccessibilityService.onKeyEvent
 */
class KeyDispatcher {

    companion object {
        private const val TAG = "KeyDispatcher"

        // Ánh xạ mã phím phần cứng với tọa độ cảm ứng (x, y) trên màn hình
        val keyMapping = mapOf<Int, Pair<Float, Float>>(
        KeyEvent.KEYCODE_W to Pair(500f, 1000f) // Phím W (Tiến Lên) (W),
        KeyEvent.KEYCODE_A to Pair(300f, 1200f) // Phím A (Sang Trái) (A),
        KeyEvent.KEYCODE_D to Pair(700f, 1200f) // Phím D (Sang Phải) (D),
        KeyEvent.KEYCODE_S to Pair(500f, 1400f) // Phím S (Lùi Lại - Bổ sung) (S)
        )

        // Theo dõi trạng thái các phím đang được giữ (để xử lý ACTION_UP nhấc tay)
        val activeHeldKeys = mutableSetOf<Int>()
    }

    /**
     * CÁCH 1: Lắng nghe trong Activity hoặc Floating Window
     * Lưu ý: Chỉ bắt được phím khi Activity hoặc View đang có tiêu điểm (Focus)
     */
    fun handleDispatchKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode

        if (keyMapping.containsKey(keyCode)) {
            val coordinates = keyMapping[keyCode]!!

            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    // event.repeatCount == 0 để chỉ bắn 1 lần khi bắt đầu nhấn, tránh bị spam liên tục khi giữ đè phím
                    if (event.repeatCount == 0) {
                        Log.d(TAG, "Nhấn phím: " + keyCode + " -> Chạm & Giữ tại: (" + coordinates.first + ", " + coordinates.second + ")")
                        activeHeldKeys.add(keyCode)
                        
                        // KHI NHẤN XUỐNG: Bắt đầu chạm giữ ngón tay (Hold) trên màn hình
                        TouchAccessibilityService.instance?.startHold(coordinates.first, coordinates.second)
                    }
                    return true // Đã xử lý, chặn không truyền tiếp cho hệ thống
                }

                KeyEvent.ACTION_UP -> {
                    Log.d(TAG, "Thả phím: " + keyCode + " -> Nhấc tay tại: (" + coordinates.first + ", " + coordinates.second + ")")
                    activeHeldKeys.remove(keyCode)
                    
                    // KHI THẢ PHÍM: Nhấc ngón tay ngay lập tức khỏi màn hình
                    TouchAccessibilityService.instance?.releaseHold(coordinates.first, coordinates.second)
                    return true
                }
            }
        }

        return false
    }

    /**
     * CÁCH 2 (KHUYÊN DÙNG CHO GAME): Lắng nghe TOÀN CỤC trong TouchAccessibilityService
     * Bắt được phím cứng (Bàn phím Bluetooth, Gamepad, Nút Âm Lượng) ngay cả khi đang chơi Game toàn màn hình!
     */
    fun handleAccessibilityKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        val keyCode = event.keyCode

        if (keyMapping.containsKey(keyCode)) {
            val coordinates = keyMapping[keyCode]!!

            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    if (event.repeatCount == 0) {
                        TouchAccessibilityService.instance?.startHold(coordinates.first, coordinates.second)
                    }
                    return true
                }
                KeyEvent.ACTION_UP -> {
                    TouchAccessibilityService.instance?.releaseHold(coordinates.first, coordinates.second)
                    return true
                }
            }
        }

        return false
    }
}
