package com.example.keymapper

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var btnEnableAccessibility: Button
    private lateinit var btnStartOverlay: Button
    private lateinit var btnTestTap: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.tv_status)
        btnEnableAccessibility = findViewById(R.id.btn_accessibility)
        btnStartOverlay = findViewById(R.id.btn_overlay)
        btnTestTap = findViewById(R.id.btn_test_tap)

        // 1. Mở cài đặt Trợ năng (Accessibility)
        btnEnableAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Hãy bật TouchAccessibilityService trong danh sách", Toast.LENGTH_LONG).show()
        }

        // 2. Bật cửa sổ nổi đè lên Game
        btnStartOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                startService(Intent(this, KeyMapperOverlayService::class.java))
                Toast.makeText(this, "Đã bật phím ảo nổi trên màn hình!", Toast.LENGTH_SHORT).show()
            }
        }

        // 3. Thử nghiệm chạm trực tiếp bằng Service
        btnTestTap.setOnClickListener {
            val service = TouchAccessibilityService.instance
            if (service != null) {
                // Chạm thử vào giữa màn hình
                val displayMetrics = resources.displayMetrics
                val centerX = displayMetrics.widthPixels / 2f
                val centerY = displayMetrics.heightPixels / 2f
                service.simulateTap(centerX, centerY, 50L) {
                    Toast.makeText(this, "Đã chạm mô phỏng thành công!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Lỗi: Dịch vụ Trợ Năng chưa được bật!", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val isServiceRunning = TouchAccessibilityService.instance != null
        if (isServiceRunning) {
            statusText.text = "Trạng thái: Đang hoạt động (Ready)"
            statusText.setTextColor(0xFF00C853.toInt())
        } else {
            statusText.text = "Trạng thái: Chưa kích hoạt"
            statusText.setTextColor(0xFFFF3D00.toInt())
        }
    }
}
