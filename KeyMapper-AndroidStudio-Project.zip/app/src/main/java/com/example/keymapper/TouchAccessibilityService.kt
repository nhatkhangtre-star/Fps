package com.example.keymapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.util.Log

/**
 * TouchAccessibilityService - Dịch vụ Accessibility mô phỏng thao tác chạm và gán phím
 * Yêu cầu: Android 7.0 (API 24) trở lên để dùng GestureDescription
 */
class TouchAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "TouchService"

        // Biến toàn cục để gọi nhanh từ bất kỳ đâu trong app (Activity, FloatingService, BroadcastReceiver)
        var instance: TouchAccessibilityService? = null
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Dịch vụ Accessibility đã kết nối thành công!")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Không cần xử lý sự kiện giao diện hệ thống ở đây
    }

    override fun onInterrupt() {
        Log.w(TAG, "Dịch vụ Accessibility bị ngắt quãng")
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    /**
     * Hàm giả lập chạm tại tọa độ (x, y) trên màn hình
     * @param x Tọa độ X (pixel thực tế màn hình)
     * @param y Tọa độ Y (pixel thực tế màn hình)
     * @param durationMs Thời gian chạm giữ (mặc định 50ms cho cú chạm nhanh)
     * @param onComplete Callback khi chạm thành công
     */
    fun simulateTap(
        x: Float,
        y: Float,
        durationMs: Long = 50L,
        onComplete: (() -> Unit)? = null,
        onCancel: (() -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gestureBuilder = GestureDescription.Builder().addStroke(stroke)

        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d(TAG, "Chạm thành công tại: ($x, $y)")
                onComplete?.invoke()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.w(TAG, "Chạm bị hủy tại: ($x, $y)")
                onCancel?.invoke()
            }
        }, null)
    }

    /**
     * Hàm giả lập chạm giữ (Long Press) tại tọa độ (x, y)
     */
    fun simulateHold(x: Float, y: Float, durationMs: Long = 1000L, onComplete: (() -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gestureBuilder = GestureDescription.Builder().addStroke(stroke)
        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onComplete?.invoke()
            }
        }, null)
    }

    private var activeHoldStroke: GestureDescription.StrokeDescription? = null

    /**
     * Chạm và GIỮ ĐÈ liên tục (Cho phím di chuyển W, A, S, D hoặc nút bắn liên thanh)
     * willContinue = true (Android 8.0+) giúp giữ ngón tay cố định trên màn hình đến khi gọi releaseHold()
     */
    fun startHold(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val stroke = GestureDescription.StrokeDescription(path, 0, 100000L, true)
            activeHoldStroke = stroke
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
            Log.d(TAG, "Bắt đầu chạm giữ (ACTION_DOWN): (" + x + ", " + y + ")")
        } else {
            simulateTap(x, y, 500L)
        }
    }

    /**
     * NHẤC NGÓN TAY khi thả phím (ACTION_UP) - Dừng di chuyển hoặc nhả nút bắn
     */
    fun releaseHold(x: Float, y: Float) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            activeHoldStroke?.let { stroke ->
                val path = Path().apply { moveTo(x, y) }
                val releaseStroke = stroke.continueStroke(path, 0, 20L, false)
                val gesture = GestureDescription.Builder().addStroke(releaseStroke).build()
                dispatchGesture(gesture, null, null)
                activeHoldStroke = null
                Log.d(TAG, "Đã nhấc ngón tay (ACTION_UP): (" + x + ", " + y + ")")
            }
        }
    }

    /**
     * Hàm giả lập vuốt / kéo màn hình từ (startX, startY) tới (endX, endY)
     */
    fun simulateSwipe(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 250L,
        onComplete: (() -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gestureBuilder = GestureDescription.Builder().addStroke(stroke)

        dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                Log.d(TAG, "Vuốt thành công: ($startX, $startY) -> ($endX, $endY)")
                onComplete?.invoke()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                super.onCancelled(gestureDescription)
                Log.w(TAG, "Vuốt bị hủy")
            }
        }, null)
    }

    /**
     * Hàm giả lập Turbo Auto-Click (chạm liên tục N lần theo chu kỳ intervalMs)
     */
    fun simulateTurbo(x: Float, y: Float, repeatTimes: Int = 10, intervalMs: Long = 80L) {
        var count = 0
        val runnable = object : Runnable {
            override fun run() {
                if (count < repeatTimes && instance != null) {
                    simulateTap(x, y, 40L)
                    count++
                    mainHandler.postDelayed(this, intervalMs)
                }
            }
        }
        mainHandler.post(runnable)
    }

    /**
     * Bắt sự kiện phím cứng (Bàn phím Bluetooth, Tay cầm chơi game Gamepad, hoặc Nút Âm Lượng Volume +/-)
     * Lưu ý: Cần bật android:canRequestFilterKeyEvents="true" trong xml cấu hình
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null || event.action != KeyEvent.ACTION_DOWN) {
            return super.onKeyEvent(event)
        }

        val keyCode = event.keyCode
        Log.d(TAG, "Bắt được phím cứng: " + keyCode + " (" + KeyEvent.keyCodeToString(keyCode) + ")")

        // Ví dụ gán phím tự động:
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                // Chạm nút bắn hoặc kỹ năng khi bấm Tăng Âm Lượng
                simulateTap(500f, 1000f)
                return true // Chặn không cho tăng âm lượng hệ thống
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                simulateTap(300f, 1200f)
                return true
            }
        }

        return super.onKeyEvent(event)
    }
}
