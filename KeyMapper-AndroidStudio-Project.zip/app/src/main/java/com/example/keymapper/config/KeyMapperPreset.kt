package com.example.keymapper.config

data class KeyAction(
    val id: String,
    val name: String,
    val triggerKey: String,
    val actionType: String,
    val x: Float,
    val y: Float,
    val endX: Float = 0f,
    val endY: Float = 0f,
    val durationMs: Long = 50L
)

object KeyMapperPreset {
    val activeBindings = listOf(
        KeyAction(
            id = "user-w",
            name = "Phím W (Tiến Lên)",
            triggerKey = "W",
            actionType = "hold",
            x = 500f,
            y = 1000f,
            endX = 0f,
            endY = 0f,
            durationMs = 500L
        ),
        KeyAction(
            id = "user-a",
            name = "Phím A (Sang Trái)",
            triggerKey = "A",
            actionType = "hold",
            x = 300f,
            y = 1200f,
            endX = 0f,
            endY = 0f,
            durationMs = 500L
        ),
        KeyAction(
            id = "user-d",
            name = "Phím D (Sang Phải)",
            triggerKey = "D",
            actionType = "hold",
            x = 700f,
            y = 1200f,
            endX = 0f,
            endY = 0f,
            durationMs = 500L
        ),
        KeyAction(
            id = "user-s",
            name = "Phím S (Lùi Lại - Bổ sung)",
            triggerKey = "S",
            actionType = "hold",
            x = 500f,
            y = 1400f,
            endX = 0f,
            endY = 0f,
            durationMs = 500L
        )
    )
}
